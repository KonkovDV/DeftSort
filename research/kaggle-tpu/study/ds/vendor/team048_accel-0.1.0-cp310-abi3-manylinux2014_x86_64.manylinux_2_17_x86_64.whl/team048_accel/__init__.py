from .team048_accel import *

__doc__ = team048_accel.__doc__
if hasattr(team048_accel, "__all__"):
    __all__ = team048_accel.__all__